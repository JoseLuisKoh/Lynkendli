import bliblip as bp

lista_e = bp.linked_list()


lista_e.add_at_front(7)
lista_e.add_at_end(8)

lista_e.print_list()
