from setuptools import find_packages, setup

setup(
    name='bliblip',
    version='0.1',
    packages=find_packages(),
    py_modules=["bliblip"],  # Lista de dependencias si tu biblioteca las tiene
)
